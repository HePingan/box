import 'dart:convert';
import 'dart:io';

import 'video_category.dart';
import 'video_source.dart';
import 'vod_item.dart';
import '../services/video_api_service.dart';
import '../../utils/app_logger.dart';

/// 单个视频源的健康检测结果
class SourceCheckResult {
  final VideoSource source;
  final bool success;
  final String stage;
  final String message;
  final String? playableUrl;
  final int categoryCount;
  final int videoCount;
  final DateTime checkedAt;

  const SourceCheckResult({
    required this.source,
    required this.success,
    required this.stage,
    required this.message,
    required this.checkedAt,
    this.playableUrl,
    this.categoryCount = 0,
    this.videoCount = 0,
  });

  @override
  String toString() {
    return 'SourceCheckResult('
        'source=${source.name}, '
        'success=$success, '
        'stage=$stage, '
        'message=$message, '
        'playableUrl=$playableUrl, '
        'categoryCount=$categoryCount, '
        'videoCount=$videoCount, '
        'checkedAt=$checkedAt'
        ')';
  }
}

/// 视频源健康检测服务
///
/// 功能：
/// 1. 检测单个源是否可用
/// 2. 批量检测多个源
/// 3. 解析详情页里的真实播放地址并 probe
/// 4. 只返回检测结果，不直接修改全局状态
class SourceHealthService {
  static const String _logTag = 'SOURCE_HEALTH';

  /// 单个请求超时
  final Duration timeout;

  /// 批量扫描时每批并发数
  final int maxConcurrent;

  const SourceHealthService({
    this.timeout = const Duration(seconds: 8),
    this.maxConcurrent = 3,
  });

  void _log(String message) {
    AppLogger.instance.log(message, tag: _logTag);
  }

  /// 兼容旧命名：检查单个源
  Future<SourceCheckResult> checkSource(VideoSource source) async {
    return _checkOne(source);
  }

  /// 兼容旧命名：检查单个源
  Future<SourceCheckResult> checkSourceHealth(VideoSource source) async {
    return _checkOne(source);
  }

  /// 批量扫描所有源
  ///
  /// [includeDisabled]
  /// - true：连 isEnabled=false 的源也扫描
  /// - false：只扫描启用源
  Future<List<SourceCheckResult>> scanAll(
    List<VideoSource> sources, {
    bool includeDisabled = false,
    Future<void> Function(SourceCheckResult result)? onEachResult,
  }) async {
    final candidates = sources
        .where((s) => includeDisabled || s.isEnabled == true)
        .where((s) => s.url.trim().isNotEmpty)
        .toList(growable: false);

    if (candidates.isEmpty) {
      _log('scanAll skipped: no candidates');
      return <SourceCheckResult>[];
    }

    _log(
      'scanAll start '
      'candidateCount=${candidates.length} '
      'includeDisabled=$includeDisabled '
      'maxConcurrent=$maxConcurrent',
    );

    final results = <SourceCheckResult>[];

    for (var i = 0; i < candidates.length; i += maxConcurrent) {
      final end = (i + maxConcurrent) > candidates.length
          ? candidates.length
          : (i + maxConcurrent);
      final batch = candidates.sublist(i, end);

      _log('scanAll batch start batchSize=${batch.length} range=[$i, $end)');

      final batchResults = await Future.wait(
        batch.map((source) => _checkOne(source)),
      );

      for (final result in batchResults) {
        results.add(result);
        if (onEachResult != null) {
          await onEachResult(result);
        }
      }
    }

    _log('scanAll done resultCount=${results.length}');
    return results;
  }

  /// 兼容旧命名：批量扫描
  Future<List<SourceCheckResult>> scanSources(
    List<VideoSource> sources, {
    bool includeDisabled = false,
    Future<void> Function(SourceCheckResult result)? onEachResult,
  }) {
    return scanAll(
      sources,
      includeDisabled: includeDisabled,
      onEachResult: onEachResult,
    );
  }

  /// 检测单个源
  Future<SourceCheckResult> _checkOne(VideoSource source) async {
    final now = DateTime.now();

    final sourceUrl = source.url.trim();
    if (sourceUrl.isEmpty) {
      return SourceCheckResult(
        source: source,
        success: false,
        stage: 'source',
        message: '源地址为空',
        checkedAt: now,
      );
    }

    try {
      _log('checkOne start source=${source.name} url=$sourceUrl');

      // 1) 拉分类
      final categories = await _fetchCategories(source);
      if (categories.isEmpty) {
        return SourceCheckResult(
          source: source,
          success: false,
          stage: 'categories',
          message: '分类为空',
          categoryCount: 0,
          checkedAt: now,
        );
      }

      // 2) 拉列表
      final firstCategory = categories.first;
      final videos = await _fetchVideoList(source, firstCategory);
      if (videos.isEmpty) {
        return SourceCheckResult(
          source: source,
          success: false,
          stage: 'list',
          message: '视频列表为空',
          categoryCount: categories.length,
          videoCount: 0,
          checkedAt: now,
        );
      }

      // 3) 拉详情
      final firstVideo = videos.first;
      final detailBaseUrl = source.detailUrl.trim().isNotEmpty
          ? source.detailUrl.trim()
          : source.url.trim();

      final detail = await _fetchDetail(detailBaseUrl, firstVideo);
      if (detail == null) {
        return SourceCheckResult(
          source: source,
          success: false,
          stage: 'detail',
          message: '详情为空',
          categoryCount: categories.length,
          videoCount: videos.length,
          checkedAt: now,
        );
      }

      // 4) 解析真实播放地址
      final playableUrl = _extractPlayableUrl(detail, source);
      if (playableUrl == null || playableUrl.trim().isEmpty) {
        return SourceCheckResult(
          source: source,
          success: false,
          stage: 'detail',
          message: '未解析到播放地址',
          categoryCount: categories.length,
          videoCount: videos.length,
          checkedAt: now,
        );
      }

      // 5) probe 播放地址
      final playable = await _probePlayableUrl(
        playableUrl,
        baseUrl: detailBaseUrl,
        headers: _buildHeaders(source),
      );

      if (!playable) {
        return SourceCheckResult(
          source: source,
          success: false,
          stage: 'play',
          message: '播放地址不可用',
          playableUrl: playableUrl,
          categoryCount: categories.length,
          videoCount: videos.length,
          checkedAt: now,
        );
      }

      return SourceCheckResult(
        source: source,
        success: true,
        stage: 'ok',
        message: '可用',
        playableUrl: playableUrl,
        categoryCount: categories.length,
        videoCount: videos.length,
        checkedAt: now,
      );
    } catch (e, st) {
      _log('checkOne exception source=${source.name} error=$e');
      _log(st.toString());

      return SourceCheckResult(
        source: source,
        success: false,
        stage: 'exception',
        message: e.toString(),
        checkedAt: now,
      );
    }
  }

  // =====================================================================
  // 数据获取
  // =====================================================================

  Future<List<VideoCategory>> _fetchCategories(VideoSource source) async {
    _log('_fetchCategories source=${source.name} url=${source.url}');
    final categories = await VideoApiService.fetchCategories(source.url)
        .timeout(timeout);
    _log(
      '_fetchCategories done source=${source.name} count=${categories.length}',
    );
    return categories;
  }

  Future<List<VodItem>> _fetchVideoList(
    VideoSource source,
    VideoCategory category,
  ) async {
    _log(
      '_fetchVideoList source=${source.name} '
      'typeId=${category.typeId} typeName=${category.typeName}',
    );

    final list = await VideoApiService.fetchVideoList(
      baseUrl: source.url,
      page: 1,
      typeId: category.typeId,
    ).timeout(timeout);

    _log('_fetchVideoList done source=${source.name} count=${list.length}');
    return list;
  }

  Future<dynamic> _fetchDetail(
    String detailBaseUrl,
    VodItem item,
  ) async {
    _log(
      '_fetchDetail detailBaseUrl=$detailBaseUrl vodId=${item.vodId}',
    );

    final detail = await VideoApiService.fetchDetail(
      detailBaseUrl,
      item.vodId,
    ).timeout(timeout);

    _log(
      '_fetchDetail done vodId=${item.vodId} '
      'success=${detail != null}',
    );

    return detail;
  }

  // =====================================================================
  // 播放地址解析
  // =====================================================================

  /// 尽量从详情对象中提取第一条可播放地址
  String? _extractPlayableUrl(dynamic detail, VideoSource source) {
    if (detail == null) return null;

    const preferredKeys = <String>[
      'vodPlayUrl',
      'vod_play_url',
      'playUrl',
      'play_url',
      'vodUrl',
      'vod_url',
      'url',
      'playUrls',
      'play_urls',
      'episodes',
      'items',
      'list',
      'data',
      'rows',
      'playList',
      'play_list',
    ];

    for (final key in preferredKeys) {
      final value = _readDynamicProperty(detail, key);
      final url = _extractUrlFromAny(value, source);
      if (url != null && url.trim().isNotEmpty) {
        _log('_extractPlayableUrl found by $key => $url');
        return url;
      }
    }

    // 兜底：直接扫一遍对象
    final fallback = _extractUrlFromAny(detail, source);
    if (fallback != null && fallback.trim().isNotEmpty) {
      _log('_extractPlayableUrl fallback => $fallback');
      return fallback;
    }

    _log('_extractPlayableUrl failed: no url found');
    return null;
  }

  String? _extractUrlFromAny(dynamic value, VideoSource source) {
    if (value == null) return null;

    if (value is String) {
      return _extractUrlFromText(value, source);
    }

    if (value is List) {
      for (final item in value) {
        final url = _extractUrlFromAny(item, source);
        if (url != null && url.trim().isNotEmpty) return url;
      }
      return null;
    }

    if (value is Map) {
      final map = Map<String, dynamic>.from(value);

      const directKeys = <String>[
        'url',
        'playUrl',
        'play_url',
        'vodPlayUrl',
        'vod_play_url',
        'episodeUrl',
        'episode_url',
        'src',
        'link',
        'address',
        'm3u8',
      ];

      for (final key in directKeys) {
        final inner = map[key];
        final url = _extractUrlFromAny(inner, source);
        if (url != null && url.trim().isNotEmpty) return url;
      }

      const nestedKeys = <String>[
        'episodes',
        'items',
        'list',
        'data',
        'rows',
        'children',
        'playUrls',
        'play_urls',
      ];

      for (final key in nestedKeys) {
        final inner = map[key];
        final url = _extractUrlFromAny(inner, source);
        if (url != null && url.trim().isNotEmpty) return url;
      }

      return null;
    }

    const objectKeys = <String>[
      'url',
      'playUrl',
      'play_url',
      'vodPlayUrl',
      'vod_play_url',
      'episodeUrl',
      'episode_url',
      'src',
      'link',
      'address',
      'm3u8',
      'episodes',
      'items',
      'list',
      'data',
      'rows',
      'children',
      'playUrls',
      'play_urls',
    ];

    for (final key in objectKeys) {
      final inner = _readDynamicProperty(value, key);
      final url = _extractUrlFromAny(inner, source);
      if (url != null && url.trim().isNotEmpty) return url;
    }

    return null;
  }

  String? _extractUrlFromText(String text, VideoSource source) {
    var input = text.trim();
    if (input.isEmpty) return null;

    // 去掉反斜杠
    input = input.replaceAll('\\', '');

    // 1) 先匹配完整 URL
    final urlRegex = RegExp(
      r'''(https?:\/\/[^\s#\$"'<>\\]+|\/\/[^\s#\$"'<>\\]+)''',
      caseSensitive: false,
    );

    final match = urlRegex.firstMatch(input);
    if (match != null) {
      var url = match.group(0)!.trim();
      if (url.startsWith('//')) {
        url = 'https:$url';
      }
      return url;
    }

    // 2) 某些源是相对路径，尝试按 source.url / source.detailUrl 解析
    if (input.startsWith('/') ||
        input.startsWith('./') ||
        input.startsWith('../')) {
      final resolved = _resolveRelativeUrl(input, source);
      if (resolved != null && resolved.isNotEmpty) return resolved;
    }

    // 3) 某些格式里会用 # / $$$ / | 混合拼接
    final separators = ['$$$', '###', '#', '|', ',', ';', '\n', '\r'];
    for (final sep in separators) {
      if (!input.contains(sep)) continue;
      final parts = input.split(sep);
      for (final part in parts) {
        final trimmed = part.trim();
        if (trimmed.isEmpty) continue;

        final m = urlRegex.firstMatch(trimmed);
        if (m != null) {
          var url = m.group(0)!.trim();
          if (url.startsWith('//')) {
            url = 'https:$url';
          }
          return url;
        }

        if (trimmed.startsWith('/') ||
            trimmed.startsWith('./') ||
            trimmed.startsWith('../')) {
          final resolved = _resolveRelativeUrl(trimmed, source);
          if (resolved != null && resolved.isNotEmpty) return resolved;
        }
      }
    }

    return null;
  }

  String? _resolveRelativeUrl(String rawUrl, VideoSource source) {
    final baseUrls = <String>[
      source.detailUrl.trim(),
      source.url.trim(),
    ];

    for (final base in baseUrls) {
      if (base.isEmpty) continue;

      final baseUri = Uri.tryParse(base);
      if (baseUri == null || !baseUri.hasScheme) continue;

      try {
        return baseUri.resolve(rawUrl).toString();
      } catch (_) {
        // ignore
      }
    }

    return null;
  }

  // =====================================================================
  // 网络探测
  // =====================================================================

  Map<String, String> _buildHeaders(VideoSource source) {
    final referer = source.url.trim();

    return <String, String>{
      'User-Agent':
          'Mozilla/5.0 (Linux; Android 13; Flutter) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36',
      'Referer': referer,
      'Origin': _originOf(referer),
      'Accept': '*/*',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    };
  }

  String _originOf(String url) {
    try {
      final uri = Uri.parse(url);
      if (!uri.hasScheme || !uri.hasAuthority) return url;
      return '${uri.scheme}://${uri.authority}';
    } catch (_) {
      return url;
    }
  }

  Future<bool> _probePlayableUrl(
    String rawUrl, {
    required String baseUrl,
    required Map<String, String> headers,
  }) async {
    final url = _normalizeUrl(rawUrl, baseUrl);
    if (url == null || url.trim().isEmpty) return false;

    final isM3u8 = url.toLowerCase().contains('.m3u8');

    final client = HttpClient()
      ..connectionTimeout = timeout
      ..idleTimeout = timeout;

    try {
      final uri = Uri.parse(url);

      // 先 HEAD
      try {
        final headReq = await client.headUrl(uri);
        for (final entry in headers.entries) {
          headReq.headers.set(entry.key, entry.value);
        }
        headReq.followRedirects = true;

        final headResp = await headReq.close().timeout(timeout);
        _log(
          '_probePlayableUrl HEAD status=${headResp.statusCode} url=$url',
        );

        if (headResp.statusCode >= 200 && headResp.statusCode < 400) {
          if (!isM3u8) {
            return true;
          }
        }
      } catch (e) {
        _log('_probePlayableUrl HEAD failed url=$url error=$e');
      }

      // 再 GET
      final getReq = await client.getUrl(uri);
      for (final entry in headers.entries) {
        getReq.headers.set(entry.key, entry.value);
      }
      getReq.followRedirects = true;

      // 非 m3u8 尝试只拉一点，避免下载完整资源
      if (!isM3u8) {
        getReq.headers.set('Range', 'bytes=0-1023');
      }

      final resp = await getReq.close().timeout(timeout);

      _log(
        '_probePlayableUrl GET status=${resp.statusCode} '
        'contentType=${resp.headers.contentType?.mimeType} '
        'url=$url',
      );

      if (resp.statusCode < 200 || resp.statusCode >= 400) {
        return false;
      }

      if (!isM3u8) {
        return true;
      }

      // m3u8 需要检查正文
      final body = await utf8.decodeStream(resp);
      final ok = body.contains('#EXTM3U') || body.contains('#EXT-X');

      _log(
        '_probePlayableUrl m3u8 bodyLength=${body.length} ok=$ok url=$url',
      );

      return ok;
    } catch (e, st) {
      _log('_probePlayableUrl exception url=$url error=$e');
      _log(st.toString());
      return false;
    } finally {
      client.close(force: true);
    }
  }

  String? _normalizeUrl(String rawUrl, String baseUrl) {
    var url = rawUrl.trim();
    if (url.isEmpty) return null;

    url = url.replaceAll('\\', '');

    // 协议相对 URL
    if (url.startsWith('//')) {
      return 'https:$url';
    }

    final parsed = Uri.tryParse(url);
    if (parsed != null && parsed.hasScheme) {
      return url;
    }

    final baseUri = Uri.tryParse(baseUrl);
    if (baseUri != null && baseUri.hasScheme) {
      try {
        return baseUri.resolve(url).toString();
      } catch (_) {
        // ignore
      }
    }

    return url;
  }

  // =====================================================================
  // 反射式读取
  // =====================================================================

  dynamic _readDynamicProperty(dynamic item, String key) {
    if (item == null) return null;

    if (item is Map) {
      return item[key];
    }

    try {
      switch (key) {
        case 'vodId':
          return item.vodId;
        case 'vod_id':
          return item.vodId;
        case 'id':
          return item.id;

        case 'vodName':
          return item.vodName;
        case 'vod_name':
          return item.vodName;
        case 'name':
          return item.name;
        case 'title':
          return item.title;

        case 'vodPic':
          return item.vodPic;
        case 'vod_pic':
          return item.vodPic;
        case 'pic':
          return item.pic;
        case 'cover':
          return item.cover;
        case 'image':
          return item.image;
        case 'img':
          return item.img;
        case 'thumb':
          return item.thumb;
        case 'poster':
          return item.poster;
        case 'vod_img':
          return item.vodImg;

        case 'vodRemarks':
          return item.vodRemarks;
        case 'vod_remarks':
          return item.vodRemarks;
        case 'remarks':
          return item.remarks;
        case 'remark':
          return item.remark;

        case 'vodPlayUrl':
          return item.vodPlayUrl;
        case 'vod_play_url':
          return item.vodPlayUrl;
        case 'playUrl':
          return item.playUrl;
        case 'play_url':
          return item.playUrl;
        case 'vodUrl':
          return item.vodUrl;
        case 'vod_url':
          return item.vodUrl;
        case 'url':
          return item.url;

        case 'playUrls':
          return item.playUrls;
        case 'play_urls':
          return item.playUrls;
        case 'playList':
          return item.playList;
        case 'play_list':
          return item.playList;

        case 'episodes':
          return item.episodes;
        case 'items':
          return item.items;
        case 'list':
          return item.list;
        case 'data':
          return item.data;
        case 'rows':
          return item.rows;
        case 'children':
          return item.children;

        default:
          return null;
      }
    } catch (_) {
      return null;
    }
  }
}