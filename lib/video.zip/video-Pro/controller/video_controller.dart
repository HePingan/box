import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import '../models/video_category.dart';
import '../models/video_source.dart';
import '../models/vod_item.dart';
import '../services/video_api_service.dart';
import '../video_module.dart';
import '../../utils/app_logger.dart';

class SourceProbeOutcome {
  final VideoSource source;
  final bool success;
  final String stage;
  final String message;
  final DateTime checkedAt;

  const SourceProbeOutcome({
    required this.source,
    required this.success,
    required this.stage,
    required this.message,
    required this.checkedAt,
  });

  @override
  String toString() {
    return 'SourceProbeOutcome('
        'source=${source.name}, '
        'success=$success, '
        'stage=$stage, '
        'message=$message, '
        'checkedAt=$checkedAt'
        ')';
  }
}

class VideoController extends ChangeNotifier {
  static const String _logTag = 'VIDEO';

  // ==================== 源站状态 ====================
  List<VideoSource> _sources = [];
  List<VideoSource> get sources => List.unmodifiable(_sources);

  List<VideoSource> get allSources => sources;

  List<VideoSource> get visibleSources =>
      List.unmodifiable(VideoModule.visibleSourcesOf(_sources));

  List<VideoSource> get hiddenSources => List.unmodifiable(
        _sources.where((s) => !VideoModule.isSourceVisible(s)).toList(),
      );

  bool isSourceVisible(VideoSource source) => VideoModule.isSourceVisible(source);

  SourceVisibilityRecord visibilityOf(VideoSource source) =>
      VideoModule.getVisibilityRecord(source);

  VideoSource? _currentSource;
  VideoSource? get currentSource => _currentSource;

  // ==================== 分类状态 ====================
  List<VideoCategory> _categories = [];
  List<VideoCategory> get categories => _categories;

  int? _currentTypeId; // 当前选中的分类，null 表示“全部”
  int? get currentTypeId => _currentTypeId;

  // ==================== 视频列表与分页状态 ====================
  List<VodItem> _videoList = [];
  List<VodItem> get videoList => _videoList;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  bool _hasMore = true;
  bool get hasMore => _hasMore;

  int _currentPage = 1;
  int get currentPage => _currentPage;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  // ==================== 源检测状态 ====================
  bool _isScanningSources = false;
  bool get isScanningSources => _isScanningSources;

  // ==================== 安全与并发控制机制 ====================
  int _requestVersion = 0;
  bool _disposed = false;

  void _log(String message) {
    AppLogger.instance.log(message, tag: _logTag);
  }

  void _logState(String prefix) {
    _log(
      '$prefix '
      'source=${_currentSource?.name ?? "-"} '
      'typeId=${_currentTypeId?.toString() ?? "all"} '
      'page=$_currentPage '
      'loading=$_isLoading '
      'scanning=$_isScanningSources '
      'hasMore=$_hasMore '
      'sources=${_sources.length} '
      'visible=${visibleSources.length} '
      'categories=${_categories.length} '
      'videos=${_videoList.length} '
      'requestVersion=$_requestVersion',
    );
  }

  @override
  void dispose() {
    _disposed = true;
    _log('dispose called, controller marked as disposed');
    super.dispose();
  }

  // ==================== 对外能力 ====================

  /// 初始化视频源，并默认加载第一个可见源的数据和分类
  Future<void> initSources(String configUrl) async {
    final int taskVersion = ++_requestVersion;

    _log(
      'initSources start taskVersion=$taskVersion configUrl=${configUrl.trim()}',
    );

    _setLoading(true);
    _errorMessage = null;
    _sources = [];
    _currentSource = null;
    _categories = [];
    _currentTypeId = null;
    _videoList = [];
    _currentPage = 1;
    _hasMore = true;
    _safeNotify();

    final url = configUrl.trim();
    if (url.isEmpty) {
      _log('initSources skipped: configUrl is empty');
      if (_isTaskActive(taskVersion)) {
        _setLoading(false);
        _safeNotify();
      }
      return;
    }

    try {
      await VideoModule.ensureVisibilityLoaded();

      _log('initSources fetching sources from $url');
      final sources = await VideoApiService.fetchSources(url);

      if (!_isTaskActive(taskVersion)) {
        _log('initSources aborted: task not active after fetchSources');
        return;
      }

      _sources = sources;
      _currentSource = visibleSources.isNotEmpty ? visibleSources.first : null;

      _log(
        'initSources sources loaded count=${_sources.length} '
        'visible=${visibleSources.length} '
        'currentSource=${_currentSource?.name ?? "null"}',
      );

      _safeNotify();

      if (_currentSource != null) {
        _log(
          'initSources loading categories + first page for source=${_currentSource!.name}',
        );

        await Future.wait([
          _loadCategoriesInternal(taskVersion, _currentSource!),
          _loadVideoListInternal(taskVersion, _currentSource!, 1, false),
        ]);

        _logState('initSources done');
      } else {
        _errorMessage = _sources.isEmpty
            ? '未解析到可用视频源'
            : '没有可用视频源（均已隐藏或失效）';
        _log('initSources failed: no usable visible source parsed from config');
      }
    } catch (e, st) {
      if (!_isTaskActive(taskVersion)) {
        _log('initSources exception ignored: task not active error=$e');
        return;
      }
      _errorMessage = '初始化视频源失败：$e';
      _log('initSources exception error=$e');
      _log(st.toString());
    } finally {
      if (_isTaskActive(taskVersion)) {
        _setLoading(false);
        _safeNotify();
        _logState('initSources finally');
      }
    }
  }

  /// 切换当前视频源，清理分类并重新加载
  Future<void> setCurrentSource(VideoSource source) async {
    if (_currentSource?.id == source.id) {
      _log('setCurrentSource skipped: same source id=${source.id}');
      return;
    }

    final int taskVersion = ++_requestVersion;

    _log(
      'setCurrentSource start taskVersion=$taskVersion '
      'from=${_currentSource?.name ?? "null"} to=${source.name}',
    );

    _currentSource = source;
    _categories = [];
    _currentTypeId = null; // 切源默认回“全部”
    _videoList = [];
    _currentPage = 1;
    _hasMore = true;
    _errorMessage = null;
    _setLoading(true);
    _safeNotify();

    try {
      _log(
        'setCurrentSource loading categories + first page for source=${source.name}',
      );

      await Future.wait([
        _loadCategoriesInternal(taskVersion, source),
        _loadVideoListInternal(taskVersion, source, 1, false),
      ]);

      _logState('setCurrentSource done');
    } catch (e, st) {
      if (_isTaskActive(taskVersion)) {
        _errorMessage = '切换视频源失败：$e';
      }
      _log('setCurrentSource exception error=$e');
      _log(st.toString());
    } finally {
      if (_isTaskActive(taskVersion)) {
        _setLoading(false);
        _safeNotify();
        _logState('setCurrentSource finally');
      }
    }
  }

  /// 切换顶部栏分类
  Future<void> setCategory(int? typeId) async {
    if (_currentTypeId == typeId) {
      _log('setCategory skipped: same typeId=${typeId?.toString() ?? "all"}');
      return;
    }

    _log(
      'setCategory start from=${_currentTypeId?.toString() ?? "all"} '
      'to=${typeId?.toString() ?? "all"}',
    );

    _currentTypeId = typeId;
    await fetchVideoList(isRefresh: true, force: true);
  }

  /// 刷新当前源或分类列表
  Future<void> refreshCurrentSource() async {
    _log('refreshCurrentSource start');
    await fetchVideoList(isRefresh: true, force: true);
  }

  /// 手动隐藏某个源
  Future<void> setSourceManualHidden(VideoSource source, bool hidden) async {
    _log(
      'setSourceManualHidden source=${source.name} hidden=$hidden',
    );

    await VideoModule.setSourceManualHidden(source, hidden);
    await _reconcileCurrentSourceAfterVisibilityChange();

    _safeNotify();
  }

  /// 恢复显示某个源
  Future<void> restoreSourceVisibility(VideoSource source) async {
    _log('restoreSourceVisibility source=${source.name}');

    await VideoModule.setSourceManualHidden(source, false);
    await VideoModule.markSourceSuccess(source);

    if (_currentSource == null) {
      await setCurrentSource(source);
      return;
    }

    await _reconcileCurrentSourceAfterVisibilityChange();
    _safeNotify();
  }

  /// 单独测试一个源
  Future<SourceProbeOutcome> probeSource(
    VideoSource source, {
    int autoHideThreshold = 2,
  }) async {
    await VideoModule.ensureVisibilityLoaded();

    final outcome = await _checkSourceHealth(source);
    await _applyProbeOutcome(
      outcome,
      autoHideThreshold: autoHideThreshold,
      reconcileCurrent: true,
    );

    return outcome;
  }

  /// 批量扫描所有源，并自动隐藏不可用源
  Future<void> scanAllSources({
    int autoHideThreshold = 2,
  }) async {
    if (_isScanningSources) return;

    await VideoModule.ensureVisibilityLoaded();

    final candidates = _sources
        .where((s) => s.isEnabled == true && s.url.trim().isNotEmpty)
        .toList(growable: false);

    if (candidates.isEmpty) {
      _log('scanAllSources skipped: no candidates');
      return;
    }

    _isScanningSources = true;
    _safeNotify();

    _log('scanAllSources start candidateCount=${candidates.length}');

    try {
      final outcomes = await Future.wait(
        candidates.map((source) => _checkSourceHealth(source)),
      );

      for (final outcome in outcomes) {
        await _applyProbeOutcome(
          outcome,
          autoHideThreshold: autoHideThreshold,
          reconcileCurrent: false,
        );
      }

      await _reconcileCurrentSourceAfterVisibilityChange();
      _logState('scanAllSources done');
    } catch (e, st) {
      _log('scanAllSources exception error=$e');
      _log(st.toString());
    } finally {
      _isScanningSources = false;
      _safeNotify();
    }
  }

  /// 拉取视频列表
  Future<void> fetchVideoList({
    bool isRefresh = false,
    bool force = false,
  }) async {
    final source = _currentSource;
    if (source == null) {
      _log('fetchVideoList skipped: currentSource is null');
      return;
    }

    if (_isLoading && !force) {
      _log(
        'fetchVideoList skipped: isLoading=$_isLoading force=$force '
        'source=${source.name}',
      );
      return;
    }

    final int taskVersion = ++_requestVersion;

    if (isRefresh) {
      _videoList = [];
      _currentPage = 1;
      _hasMore = true;
    }

    _errorMessage = null;
    _setLoading(true);
    _safeNotify();

    try {
      await _loadVideoListInternal(taskVersion, source, _currentPage, !isRefresh);

      _logState('fetchVideoList done');
    } catch (e, st) {
      if (_isTaskActive(taskVersion)) {
        _errorMessage = '加载视频列表失败：$e';
      }
      _log('fetchVideoList exception error=$e');
      _log(st.toString());
    } finally {
      if (_isTaskActive(taskVersion)) {
        _setLoading(false);
        _safeNotify();
      }
    }
  }

  /// 加载更多（下一页）
  Future<void> loadMore() async {
    final source = _currentSource;
    if (source == null || _isLoading || !_hasMore) return;

    final int taskVersion = ++_requestVersion;
    _errorMessage = null;
    _setLoading(true);
    _safeNotify();

    try {
      await _loadVideoListInternal(taskVersion, source, _currentPage, true);
    } catch (e, st) {
      if (_isTaskActive(taskVersion)) {
        _errorMessage = '加载更多失败：$e';
      }
    } finally {
      if (_isTaskActive(taskVersion)) {
        _setLoading(false);
        _safeNotify();
      }
    }
  }

  // ==================== 内部请求方法 ====================

  Future<void> _loadCategoriesInternal(
    int taskVersion,
    VideoSource source,
  ) async {
    try {
      final cats = await VideoApiService.fetchCategories(source.url);

      if (!_isTaskActive(taskVersion)) return;
      if (_currentSource?.id != source.id) return;

      _categories = cats;
      _safeNotify();

    } catch (e) {
      debugPrint('拉取分类失败忽略: $e');
    }
  }

  Future<void> _loadVideoListInternal(
    int taskVersion,
    VideoSource source,
    int page,
    bool append,
  ) async {
    try {
      final List<VodItem> newList = await VideoApiService.fetchVideoList(
        baseUrl: source.url,
        page: page,
        typeId: _currentTypeId,
      );

      if (!_isTaskActive(taskVersion)) return;
      if (_currentSource?.id != source.id) return;

      if (!append) {
        _videoList = [];
      }

      if (newList.isEmpty) {
        _hasMore = false;
      } else {
        _videoList.addAll(newList);
        _currentPage = page + 1;
        _hasMore = true;
      }

      _errorMessage = null;
      _safeNotify();
    } catch (e) {
      if (!_isTaskActive(taskVersion)) return;
      _errorMessage = '加载视频列表失败：$e';
      if (!append && _videoList.isEmpty) _videoList = [];
    }
  }

  // ==================== 源健康检测 ====================

  Future<void> _applyProbeOutcome(
    SourceProbeOutcome outcome, {
    required int autoHideThreshold,
    required bool reconcileCurrent,
  }) async {
    final record = VideoModule.getVisibilityRecord(outcome.source);

    if (outcome.success) {
      await VideoModule.markSourceSuccess(outcome.source);
    } else {
      final shouldAutoHide = (record.failCount + 1) >= autoHideThreshold;
      await VideoModule.markSourceFailure(
        outcome.source,
        reason: '${outcome.stage}: ${outcome.message}',
        autoHide: shouldAutoHide,
      );
    }

    if (reconcileCurrent) {
      await _reconcileCurrentSourceAfterVisibilityChange();
    }

    _safeNotify();
  }

  Future<SourceProbeOutcome> _checkSourceHealth(VideoSource source) async {
    final now = DateTime.now();

    try {
      // 1. 测分类
      final categories = await _fetchCategories(source);
      if (categories.isEmpty) {
        return SourceProbeOutcome(
          source: source,
          success: false,
          stage: 'categories',
          message: '分类为空',
          checkedAt: now,
        );
      }

      // 2. 测列表
      final firstCategory = categories.first;
      final videos = await _fetchVideoList(source, firstCategory);
      if (videos.isEmpty) {
        return SourceProbeOutcome(
          source: source,
          success: false,
          stage: 'list',
          message: '视频列表为空',
          checkedAt: now,
        );
      }

      // 3. 测详情 (🚨已修复空安全)
      final firstVideo = videos.first;
      final detail = await _fetchDetail(source, firstVideo);
      
      if (detail == null) {
        return SourceProbeOutcome(
          source: source,
          success: false,
          stage: 'detail',
          message: '详情为空',
          checkedAt: now,
        );
      }

      final playableUrl = _extractFirstPlayableUrl(detail);
      if (playableUrl == null || playableUrl.trim().isEmpty) {
        return SourceProbeOutcome(
          source: source,
          success: false,
          stage: 'detail',
          message: '未解析到播放地址',
          checkedAt: now,
        );
      }

      // 4. 真正 probe 播放链接
      final playable = await _probePlayableUrl(
        playableUrl,
        headers: _buildHeaders(source),
      );

      if (!playable) {
        return SourceProbeOutcome(
          source: source,
          success: false,
          stage: 'play',
          message: '播放地址不可用',
          checkedAt: now,
        );
      }

      return SourceProbeOutcome(
        source: source,
        success: true,
        stage: 'ok',
        message: '可用',
        checkedAt: now,
      );
    } catch (e) {
      return SourceProbeOutcome(
        source: source,
        success: false,
        stage: 'exception',
        message: e.toString(),
        checkedAt: now,
      );
    }
  }

  Future<List<VideoCategory>> _fetchCategories(VideoSource source) async {
    return await VideoApiService.fetchCategories(source.url);
  }

  Future<List<VodItem>> _fetchVideoList(
    VideoSource source,
    VideoCategory category,
  ) async {
    return await VideoApiService.fetchVideoList(
      baseUrl: source.url,
      page: 1,
      typeId: category.typeId,
    );
  }

  // 🚨【修复核心】：返回 Future<VodItem?>
  Future<VodItem?> _fetchDetail(VideoSource source, VodItem item) async {
    final detailBaseUrl =
        source.detailUrl.trim().isNotEmpty ? source.detailUrl : source.url;
    return await VideoApiService.fetchDetail(detailBaseUrl, item.vodId);
  }

  String? _extractFirstPlayableUrl(VodItem detail) {
    try {
      final groups = detail.playUrls;
      if (groups.isEmpty) return null;
      final firstGroup = groups.first;
      if (firstGroup.episodes.isEmpty) return null;
      return firstGroup.episodes.first.url;
    } catch (_) {
      return null;
    }
  }

  Map<String, String> _buildHeaders(VideoSource source) {
    return <String, String>{
      'User-Agent':
          'Mozilla/5.0 (Linux; Android 13; Flutter) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36',
      'Referer': source.url,
      'Origin': source.url,
      'Accept': '*/*',
    };
  }

  Future<bool> _probePlayableUrl(
    String url, {
    required Map<String, String> headers,
  }) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 8)
      ..idleTimeout = const Duration(seconds: 8);

    try {
      final uri = Uri.parse(url);

      // 优先 HEAD，失败再 GET
      try {
        final headReq = await client.headUrl(uri);
        headers.forEach((k, v) => headReq.headers.set(k, v));
        headReq.followRedirects = true;

        final headResp = await headReq.close().timeout(
              const Duration(seconds: 8),
            );

        if (headResp.statusCode >= 200 && headResp.statusCode < 400) {
          if (!url.contains('.m3u8')) return true;
        }
      } catch (_) {
        // HEAD 失败不直接判死
      }

      final getReq = await client.getUrl(uri);
      headers.forEach((k, v) => getReq.headers.set(k, v));
      getReq.followRedirects = true;

      if (url.contains('.m3u8')) {
        final resp = await getReq.close().timeout(
              const Duration(seconds: 8),
            );
        if (resp.statusCode < 200 || resp.statusCode >= 400) return false;
        final body = await utf8.decodeStream(resp);
        return body.contains('#EXTM3U') || body.contains('#EXT-X');
      }

      final resp = await getReq.close().timeout(
            const Duration(seconds: 8),
          );
      return resp.statusCode >= 200 && resp.statusCode < 400;
    } catch (_) {
      return false;
    } finally {
      client.close(force: true);
    }
  }

  // ==================== 保护机制辅助方法 ====================

  Future<void> _reconcileCurrentSourceAfterVisibilityChange() async {
    final current = _currentSource;

    if (current != null && VideoModule.isSourceVisible(current)) {
      return;
    }

    final next = visibleSources.isNotEmpty ? visibleSources.first : null;

    if (next != null) {
      if (_currentSource?.id != next.id) {
        await setCurrentSource(next);
      }
      return;
    }

    await _clearCurrentSelection('暂无可用视频源');
  }

  Future<void> _clearCurrentSelection(String message) async {
    _currentSource = null;
    _categories = [];
    _currentTypeId = null;
    _videoList = [];
    _currentPage = 1;
    _hasMore = false;
    _errorMessage = message;
    _safeNotify();
  }

  void _setLoading(bool value) {
    _isLoading = value;
  }

  bool _isTaskActive(int taskVersion) {
    if (_disposed) return false;
    return taskVersion == _requestVersion;
  }

  void _safeNotify() {
    if (!_disposed) {
      notifyListeners();
    }
  }
}