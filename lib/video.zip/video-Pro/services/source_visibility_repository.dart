import 'package:hive_flutter/hive_flutter.dart';
import '../models/source_visibility_record.dart';
import '../models/video_source.dart';

class SourceVisibilityRepository {
  static const String _boxName = 'video_source_visibility_box';
  Box? _box;

  Future<void> init() async {
    _box ??= await Hive.openBox(_boxName);
  }

  String keyOf(VideoSource source) {
    final id = source.id;
    if (id != null && id.toString().trim().isNotEmpty) {
      return id.toString().trim();
    }
    return source.url.trim();
  }

  SourceVisibilityRecord getRecord(VideoSource source) {
    final key = keyOf(source);
    final raw = _box?.get(key);
    if (raw is Map) {
      return SourceVisibilityRecord.fromJson(Map<String, dynamic>.from(raw));
    }
    return SourceVisibilityRecord(key: key);
  }

  SourceVisibilityRecord getRecordByKey(String key) {
    final raw = _box?.get(key);
    if (raw is Map) {
      return SourceVisibilityRecord.fromJson(Map<String, dynamic>.from(raw));
    }
    return SourceVisibilityRecord(key: key);
  }

  Future<void> saveRecord(SourceVisibilityRecord record) async {
    await init();
    await _box!.put(record.key, record.toJson());
  }

  Future<void> setManualHidden(
    VideoSource source,
    bool hidden, {
    String? reason,
  }) async {
    final record = getRecord(source);
    final updated = record.copyWith(
      manualHidden: hidden,
      lastReason: reason ?? record.lastReason,
      lastCheckedAt: DateTime.now(),
    );
    await saveRecord(updated);
  }

  Future<void> setAutoHidden(
    VideoSource source,
    bool hidden, {
    String? reason,
    int? failCount,
    bool? lastPlayable,
  }) async {
    final record = getRecord(source);
    final updated = record.copyWith(
      autoHidden: hidden,
      failCount: failCount ?? record.failCount,
      lastReason: reason ?? record.lastReason,
      lastPlayable: lastPlayable ?? record.lastPlayable,
      lastCheckedAt: DateTime.now(),
    );
    await saveRecord(updated);
  }

  Future<void> markSuccess(VideoSource source) async {
    final record = getRecord(source);
    final updated = record.copyWith(
      autoHidden: false,
      failCount: 0,
      lastPlayable: true,
      lastReason: 'ok',
      lastCheckedAt: DateTime.now(),
    );
    await saveRecord(updated);
  }

  Future<void> markFailure(
    VideoSource source, {
    required String reason,
    required bool autoHide,
  }) async {
    final record = getRecord(source);
    final failCount = record.failCount + 1;
    final updated = record.copyWith(
      autoHidden: autoHide,
      failCount: failCount,
      lastPlayable: false,
      lastReason: reason,
      lastCheckedAt: DateTime.now(),
    );
    await saveRecord(updated);
  }

  bool isVisible(VideoSource source) {
    final record = getRecord(source);
    return !record.isHidden;
  }

  List<VideoSource> filterVisible(
    List<VideoSource> sources, {
    bool includeHidden = false,
  }) {
    if (includeHidden) return sources;
    return sources.where((s) => isVisible(s)).toList();
  }
}