import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/video_category.dart';
import '../models/video_source.dart';
import '../models/vod_item.dart';
import '../../utils/app_logger.dart';

class VideoApiService {
  static const Duration _defaultTimeout = Duration(seconds: 10);

  static const Map<String, String> _defaultHeaders = {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9',
  };

  static void _log(String message) {
    AppLogger.instance.log(message, tag: 'HTTP');
  }

  static String _preview(String text, {int max = 800}) {
    final normalized = text.replaceAll('\r\n', '\n');
    if (normalized.length <= max) return normalized;
    return '${normalized.substring(0, max)}\n...<truncated ${normalized.length - max} chars>';
  }

  static Map<String, String> _redactHeaders(Map<String, String> headers) {
    final out = <String, String>{};
    headers.forEach((k, v) {
      final key = k.toLowerCase();
      if (key == 'cookie' || key == 'authorization') {
        out[k] = '<redacted>';
      } else {
        out[k] = v;
      }
    });
    return out;
  }

  static Map<String, String> _mergeHeaders([
    Map<String, String>? extraHeaders,
  ]) {
    final headers = <String, String>{..._defaultHeaders};
    if (extraHeaders != null && extraHeaders.isNotEmpty) {
      headers.addAll(extraHeaders);
    }
    return headers;
  }

  static String _withQuery(String baseUrl, Map<String, String> params) {
    final trimmed = baseUrl.trim();
    if (trimmed.isEmpty) return trimmed;
    if (params.isEmpty) return trimmed;

    final uri = Uri.tryParse(trimmed);
    if (uri == null || !uri.hasScheme) {
      final separator = trimmed.contains('?') ? '&' : '?';
      return '$trimmed$separator${params.entries.map((e) => '${e.key}=${Uri.encodeQueryComponent(e.value)}').join('&')}';
    }

    final merged = Map<String, String>.from(uri.queryParameters);
    merged.addAll(params);
    return uri.replace(queryParameters: merged).toString();
  }

  static Map<String, dynamic>? _asMap(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return Map<String, dynamic>.from(value);
    return null;
  }

  static List<dynamic> _extractList(dynamic decoded) {
    if (decoded is List) return decoded;

    if (decoded is Map) {
      final map = Map<String, dynamic>.from(decoded);

      for (final key in const [
        'list',
        'data',
        'results',
        'sources',
        'items',
        'rows',
        'class',
      ]) {
        final value = map[key];
        if (value is List) return value;

        if (value is Map) {
          final nested = _asMap(value);
          if (nested != null) {
            for (final nestedKey in const ['list', 'data', 'items', 'rows']) {
              final nestedValue = nested[nestedKey];
              if (nestedValue is List) return nestedValue;
            }
          }
        }
      }
    }

    return const [];
  }

  static Future<dynamic> _getJson(
    String url, {
    Duration timeout = _defaultTimeout,
    Map<String, String>? headers,
    String tag = 'HTTP',
  }) async {
    final mergedHeaders = _mergeHeaders(headers);

    _log('GET $url');
    _log('headers=${_redactHeaders(mergedHeaders)}');

    try {
      final response = await http
          .get(
            Uri.parse(url),
            headers: mergedHeaders,
          )
          .timeout(timeout);

      final body = utf8.decode(
        response.bodyBytes,
        allowMalformed: true,
      ).trim();

      _log(
        'RESPONSE $url status=${response.statusCode} '
        'contentType=${response.headers['content-type']} '
        'bodyLength=${body.length}',
      );

      if (body.isNotEmpty) {
        _log('preview:\n${_preview(body)}');
      }

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('HTTP ${response.statusCode}');
      }

      if (body.isEmpty) {
        throw Exception('Empty body');
      }

      try {
        return jsonDecode(body);
      } catch (e) {
        _log('jsonDecode failed url=$url error=$e');
        throw Exception('Invalid JSON');
      }
    } catch (e, st) {
      _log('GET failed url=$url error=$e');
      _log(st.toString());
      rethrow;
    }
  }

  static Future<List<VideoSource>> fetchSources(String configUrl) async {
    final url = configUrl.trim();
    if (url.isEmpty) return [];

    try {
      _log('fetchSources start url=$url');

      final decoded = await _getJson(url);
      final list = _extractList(decoded);

      final result = list
          .map(_asMap)
          .whereType<Map<String, dynamic>>()
          .map(VideoSource.fromJson)
          .toList(growable: false);

      _log('fetchSources parsed count=${result.length}');
      return result;
    } catch (e, st) {
      debugPrint('加载源配置失败: $e');
      _log('fetchSources failed url=$url error=$e');
      _log(st.toString());
      return [];
    }
  }

  static Future<List<VideoCategory>> fetchCategories(String baseUrl) async {
    final url = baseUrl.trim();
    if (url.isEmpty) return [];

    final requestUrl = _withQuery(url, {
      'ac': 'list',
    });

    try {
      _log('fetchCategories start baseUrl=$url requestUrl=$requestUrl');

      final decoded = await _getJson(requestUrl);

      if (decoded is Map) {
        final map = Map<String, dynamic>.from(decoded);
        final classList = map['class'];
        if (classList is List) {
          final result = classList
              .map(_asMap)
              .whereType<Map<String, dynamic>>()
              .map(VideoCategory.fromJson)
              .toList(growable: false);

          _log('fetchCategories parsed classCount=${result.length}');
          return result;
        }
      }

      final list = _extractList(decoded);
      final result = list
          .map(_asMap)
          .whereType<Map<String, dynamic>>()
          .map(VideoCategory.fromJson)
          .toList(growable: false);

      _log('fetchCategories parsed listCount=${result.length}');
      return result;
    } catch (e, st) {
      debugPrint('获取分类列表失败: $e');
      _log('fetchCategories failed baseUrl=$url requestUrl=$requestUrl error=$e');
      _log(st.toString());
      return [];
    }
  }

  static Future<List<VodItem>> fetchVideoList({
    required String baseUrl,
    int page = 1,
    int? typeId,
  }) async {
    final url = baseUrl.trim();
    if (url.isEmpty) return [];

    final params = <String, String>{
      'ac': 'list',
      'pg': '$page',
    };
    if (typeId != null) {
      params['t'] = '$typeId';
    }

    final requestUrl = _withQuery(url, params);

    try {
      _log(
        'fetchVideoList start baseUrl=$url requestUrl=$requestUrl page=$page typeId=$typeId',
      );

      final decoded = await _getJson(requestUrl);
      final list = _extractList(decoded);

      final result = list
          .map(_asMap)
          .whereType<Map<String, dynamic>>()
          .map(VodItem.fromJson)
          .toList(growable: false);

      _log('fetchVideoList parsed count=${result.length} page=$page typeId=$typeId');
      return result;
    } catch (e, st) {
      debugPrint('获取视频列表失败: $e');
      _log('fetchVideoList failed baseUrl=$url requestUrl=$requestUrl error=$e');
      _log(st.toString());
      return [];
    }
  }

  static Future<List<VodItem>> searchVideo(
    String baseUrl,
    String keyword,
  ) async {
    final url = baseUrl.trim();
    final query = keyword.trim();
    if (url.isEmpty || query.isEmpty) return [];

    final requestUrl = _withQuery(url, {
      'ac': 'list',
      'wd': query,
    });

    try {
      _log(
        'searchVideo start baseUrl=$url requestUrl=$requestUrl keyword=$query',
      );

      final decoded = await _getJson(requestUrl);
      final list = _extractList(decoded);

      final result = list
          .map(_asMap)
          .whereType<Map<String, dynamic>>()
          .map(VodItem.fromJson)
          .toList(growable: false);

      _log('searchVideo parsed count=${result.length} keyword=$query');
      return result;
    } catch (e, st) {
      debugPrint('搜索失败: $e');
      _log('searchVideo failed baseUrl=$url requestUrl=$requestUrl error=$e');
      _log(st.toString());
      return [];
    }
  }

  static Future<VodItem?> fetchDetail(String baseUrl, int vodId) async {
    final url = baseUrl.trim();
    if (url.isEmpty || vodId <= 0) return null;

    final requestUrl = _withQuery(url, {
      'ac': 'detail',
      'ids': '$vodId',
    });

    try {
      _log('fetchDetail start baseUrl=$url requestUrl=$requestUrl vodId=$vodId');

      final decoded = await _getJson(requestUrl);

      final list = _extractList(decoded)
          .map(_asMap)
          .whereType<Map<String, dynamic>>()
          .toList(growable: false);

      if (list.isNotEmpty) {
        final item = VodItem.fromJson(list.first);
        _log('fetchDetail parsed from list vodId=$vodId success=true');
        return item;
      }

      final map = _asMap(decoded);
      if (map != null) {
        final hasVodFields = map.containsKey('vod_id') ||
            map.containsKey('vodId') ||
            map.containsKey('vod_name') ||
            map.containsKey('vodName');

        if (hasVodFields) {
          final item = VodItem.fromJson(map);
          _log('fetchDetail parsed from map vodId=$vodId success=true');
          return item;
        }
      }

      if (decoded is List && decoded.isNotEmpty && decoded.first is Map) {
        final item = VodItem.fromJson(
          Map<String, dynamic>.from(decoded.first as Map),
        );
        _log('fetchDetail parsed from raw list vodId=$vodId success=true');
        return item;
      }

      _log('fetchDetail parsed result is null vodId=$vodId');
    } catch (e, st) {
      debugPrint('获取详情失败: $e');
      _log('fetchDetail failed baseUrl=$url requestUrl=$requestUrl vodId=$vodId error=$e');
      _log(st.toString());
    }

    return null;
  }
}