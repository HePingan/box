import '../novel/core/cache_store.dart';
import 'core/archive_video_source.dart';
import 'core/composite_video_source.dart';
import 'core/sample_video_source.dart';
import 'core/video_repository.dart';
import 'core/video_source.dart';

class VideoModule {
  static VideoRepository? _repository;

  static VideoRepository get repository {
    _repository ??= VideoRepository(
      source: const _UnconfiguredVideoSource(),
      cache: CacheStore(namespace: 'video_module'),
    );
    return _repository!;
  }

  static bool get isConfigured =>
      _repository != null && _repository!.source is! _UnconfiguredVideoSource;

  static void configure({
    required VideoSource source,
    CacheStore? cache,
  }) {
    _repository = VideoRepository(
      source: source,
      cache: cache ?? CacheStore(namespace: 'video_module'),
    );
  }

  /// 合法免费内容源：Internet Archive + 样例兜底
  static void configurePublicVideoSource({CacheStore? cache}) {
    configure(
      source: CompositeVideoSource(
        archive: ArchiveVideoSource(),
        sample: const SampleVideoSource(),
      ),
      cache: cache,
    );
  }

  static void resetForTest() {
    _repository = null;
  }
}

class _UnconfiguredVideoSource implements VideoSource {
  const _UnconfiguredVideoSource();

  StateError _err() => StateError(
        'VideoModule 未配置。请先调用 VideoModule.configure(...) '
        '或 VideoModule.configurePublicVideoSource()',
      );

  @override
  String get sourceName => 'unconfigured';

  @override
  List<VideoCategory> get categories => const [];

  @override
  Future<List<VideoItem>> searchVideos(String keyword, {int page = 1}) {
    return Future.error(_err());
  }

  @override
  Future<List<VideoItem>> fetchByPath(String path, {int page = 1}) {
    return Future.error(_err());
  }

  @override
  Future<VideoDetail> fetchDetail({
    required String videoId,
    String? detailUrl,
  }) {
    return Future.error(_err());
  }
}