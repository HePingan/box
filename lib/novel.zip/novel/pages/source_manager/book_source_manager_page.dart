import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../controllers/novel_list_controller.dart';
import '../../core/rule_novel_source.dart';
import '../../novel_module.dart';
import '../novel_list_page.dart';
import 'book_source_manager.dart';
import 'book_source_model.dart';

class BookSourceManagerPage extends StatefulWidget {
  const BookSourceManagerPage({
    super.key,
    this.startupMessage = '',
  });

  final String startupMessage;

  @override
  State<BookSourceManagerPage> createState() => _BookSourceManagerPageState();
}

class _BookSourceManagerPageState extends State<BookSourceManagerPage> {
  final TextEditingController _searchController = TextEditingController();

  String _keyword = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _showImportDialog() async {
    final inputController = TextEditingController();

    final text = await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('导入规则书源'),
          content: SizedBox(
            width: 560,
            child: TextField(
              controller: inputController,
              maxLines: 16,
              decoration: const InputDecoration(
                hintText: '粘贴单个书源 JSON、多个书源数组 JSON，或按段分隔的多个 JSON',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, inputController.text),
              child: const Text('导入'),
            ),
          ],
        );
      },
    );

    if (!mounted || text == null || text.trim().isEmpty) return;

    final manager = context.read<BookSourceManager>();
    final count = await manager.importFromText(text);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(count > 0 ? '成功导入 $count 个书源' : '没有解析到有效书源'),
      ),
    );
  }

  Future<void> _showEditorDialog({BookSourceModel? source}) async {
    final controller = TextEditingController(
      text: source == null
          ? const JsonEncoder.withIndent('  ').convert({
              'bookSourceName': '',
              'bookSourceUrl': '',
              'bookSourceGroup': '',
              'searchUrl': '',
              'exploreUrl': '',
              'ruleSearch': {},
              'ruleBookInfo': {},
              'ruleToc': {},
              'ruleContent': {},
            })
          : const JsonEncoder.withIndent('  ').convert(source.toJson()),
    );

    final raw = await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(source == null ? '新增书源' : '编辑书源'),
          content: SizedBox(
            width: 620,
            child: TextField(
              controller: controller,
              maxLines: 18,
              decoration: const InputDecoration(
                hintText: '请输入单个规则书源 JSON',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, controller.text),
              child: const Text('保存'),
            ),
          ],
        );
      },
    );

    if (!mounted || raw == null || raw.trim().isEmpty) return;

    try {
      final decoded = jsonDecode(raw);

      if (decoded is! Map) {
        throw const FormatException('编辑模式只接受单个书源 JSON 对象，不接受数组');
      }

      final next = BookSourceModel.fromJson(Map<String, dynamic>.from(decoded));
      final manager = context.read<BookSourceManager>();

      if (source != null && source.id != next.id) {
        await manager.deleteById(source.id);
      }

      await manager.addOrUpdate(next);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(source == null ? '书源已新增' : '书源已更新')),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('保存失败：$e')),
      );
    }
  }

  Future<void> _confirmDelete(BookSourceModel source) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('删除书源'),
          content: Text('确定删除「${source.bookSourceName}」吗？'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('取消'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('删除'),
            ),
          ],
        );
      },
    );

    if (ok != true || !mounted) return;

    await context.read<BookSourceManager>().deleteById(source.id);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已删除书源')),
    );
  }

  Future<void> _previewSource(BookSourceModel source) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: SelectableText(
                const JsonEncoder.withIndent('  ').convert(source.toJson()),
                style: const TextStyle(fontSize: 13, height: 1.5),
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _exportSource(BookSourceModel source) async {
    await Clipboard.setData(
      ClipboardData(text: const JsonEncoder.withIndent('  ').convert(source.toJson())),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制书源：${source.bookSourceName}')),
    );
  }

  Future<void> _exportCurrentSource() async {
    final manager = context.read<BookSourceManager>();
    final current = manager.currentSource;

    if (current == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前没有正在使用的书源')),
      );
      return;
    }

    await _exportSource(current);
  }

  Future<void> _testSource(BookSourceModel source) async {
    final keywordController = TextEditingController(text: '斗罗');

    final keyword = await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('测试书源'),
          content: TextField(
            controller: keywordController,
            decoration: const InputDecoration(
              hintText: '请输入测试搜索关键词',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, keywordController.text),
              child: const Text('开始测试'),
            ),
          ],
        );
      },
    );

    if (!mounted || keyword == null || keyword.trim().isEmpty) return;

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final sourceImpl = RuleNovelSource.fromBookSourceJson(source.toJson());
      final books = await sourceImpl.searchBooks(keyword.trim(), page: 1);

      if (!mounted) return;
      Navigator.of(context).pop();

      final preview = books.take(8).toList();

      await showDialog<void>(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('测试成功：共 ${books.length} 条'),
            content: SizedBox(
              width: 520,
              child: books.isEmpty
                  ? const Text('请求成功，但未返回搜索结果。')
                  : ListView.separated(
                      shrinkWrap: true,
                      itemCount: preview.length,
                      separatorBuilder: (_, __) => const Divider(height: 16),
                      itemBuilder: (_, i) {
                        final b = preview[i];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              b.title.isNotEmpty ? b.title : '未知书名',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              [
                                if (b.author.isNotEmpty) b.author,
                                if (b.category.isNotEmpty) b.category,
                                if (b.status.isNotEmpty) b.status,
                              ].join(' · ').ifEmpty('暂无更多信息'),
                              style: const TextStyle(
                                fontSize: 12.5,
                                color: Colors.black54,
                              ),
                            ),
                          ],
                        );
                      },
                    ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('关闭'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      if (!mounted) return;
      Navigator.of(context).pop();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('测试失败：$e')),
      );
    }
  }

  Future<void> _applySource(BookSourceModel source) async {
    final manager = context.read<BookSourceManager>();

    await manager.setCurrentSource(source.id, ensureEnabled: true);

    NovelModule.configureRuleSource(
      bookSourceJson: source.toJson(),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已切换到书源：${source.bookSourceName}')),
    );

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => ChangeNotifierProvider(
          create: (_) => NovelListController(),
          child: const NovelListPageWithProvider(),
        ),
      ),
      (_) => false,
    );
  }

  Widget _buildStatusChips(
    BookSourceModel source,
    BookSourceManager manager,
  ) {
    final chips = <Widget>[];

    if (manager.currentSourceId == source.id) {
      chips.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.orange.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text(
            '当前使用',
            style: TextStyle(
              color: Colors.deepOrange,
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }

    if (source.enabled) {
      chips.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.green.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text(
            '已启用',
            style: TextStyle(
              color: Colors.green,
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    } else {
      chips.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text(
            '未启用',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }

    if (source.exploreUrl.isNotEmpty) {
      chips.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.blue.withOpacity(0.10),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text(
            '支持发现页',
            style: TextStyle(
              color: Colors.blue,
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: chips,
    );
  }

  Widget _buildSourceCard(
    BookSourceModel source,
    BookSourceManager manager,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  source.bookSourceName.isNotEmpty
                      ? source.bookSourceName
                      : '未命名书源',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Switch(
                value: source.enabled,
                onChanged: (v) async {
                  await manager.setEnabled(source.id, v);
                },
              ),
            ],
          ),
          _buildStatusChips(source, manager),
          const SizedBox(height: 10),
          if (source.bookSourceGroup.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                '分组：${source.bookSourceGroup}',
                style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 12.5,
                ),
              ),
            ),
          Text(
            source.bookSourceUrl,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 12.5,
            ),
          ),
          if (source.searchUrl.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              '搜索：${source.searchUrl}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.black45,
                fontSize: 12,
              ),
            ),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton(
                onPressed: () => _applySource(source),
                child: Text(
                  manager.currentSourceId == source.id ? '重新使用' : '启用并使用',
                ),
              ),
              OutlinedButton(
                onPressed: () => _showEditorDialog(source: source),
                child: const Text('编辑'),
              ),
              OutlinedButton(
                onPressed: () => _testSource(source),
                child: const Text('测试'),
              ),
              OutlinedButton(
                onPressed: () => _exportSource(source),
                child: const Text('导出'),
              ),
              OutlinedButton(
                onPressed: () => _previewSource(source),
                child: const Text('查看'),
              ),
              OutlinedButton(
                onPressed: () => _confirmDelete(source),
                child: const Text('删除'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final manager = context.watch<BookSourceManager>();
    final sources = manager.search(_keyword);

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          '书源管理',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            tooltip: '新增书源',
            onPressed: () => _showEditorDialog(),
            icon: const Icon(Icons.add_box_outlined),
          ),
          IconButton(
            tooltip: '导入书源',
            onPressed: _showImportDialog,
            icon: const Icon(Icons.playlist_add),
          ),
          IconButton(
            tooltip: '导出当前书源',
            onPressed: _exportCurrentSource,
            icon: const Icon(Icons.ios_share_outlined),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showImportDialog,
        icon: const Icon(Icons.add),
        label: const Text('导入书源'),
      ),
      body: Column(
        children: [
          if (widget.startupMessage.trim().isNotEmpty)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                widget.startupMessage,
                style: const TextStyle(
                  color: Colors.deepOrange,
                  fontSize: 13,
                ),
              ),
            ),
          if (manager.currentSource != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '当前默认书源：${manager.currentSource!.bookSourceName}',
                style: const TextStyle(
                  color: Colors.blue,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            child: TextField(
              controller: _searchController,
              onChanged: (v) => setState(() => _keyword = v),
              decoration: InputDecoration(
                hintText: '搜索书源名称 / 分组 / 域名',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _keyword.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _keyword = '');
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderSide: BorderSide.none,
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          Expanded(
            child: sources.isEmpty
                ? ListView(
                    padding: const EdgeInsets.fromLTRB(16, 40, 16, 100),
                    children: const [
                      Center(
                        child: Text(
                          '还没有书源，点击右下角“导入书源”开始',
                          style: TextStyle(color: Colors.black54),
                        ),
                      ),
                    ],
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                    itemCount: sources.length,
                    itemBuilder: (_, i) => _buildSourceCard(sources[i], manager),
                  ),
          ),
        ],
      ),
    );
  }
}

extension on String {
  String ifEmpty(String fallback) {
    return trim().isEmpty ? fallback : this;
  }
}