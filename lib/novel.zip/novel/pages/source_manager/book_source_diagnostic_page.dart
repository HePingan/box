import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'book_source_diagnostic.dart';
import 'book_source_model.dart';

class BookSourceDiagnosticPage extends StatefulWidget {
  const BookSourceDiagnosticPage({
    super.key,
    required this.source,
    this.initialKeyword = '斗罗',
  });

  final BookSourceModel source;
  final String initialKeyword;

  @override
  State<BookSourceDiagnosticPage> createState() =>
      _BookSourceDiagnosticPageState();
}

class _BookSourceDiagnosticPageState extends State<BookSourceDiagnosticPage> {
  late final TextEditingController _keywordController;

  bool _running = false;
  String _runtimeError = '';
  BookSourceDiagnosticReport? _report;

  @override
  void initState() {
    super.initState();
    _keywordController = TextEditingController(text: widget.initialKeyword);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _runDiagnostic();
    });
  }

  @override
  void dispose() {
    _keywordController.dispose();
    super.dispose();
  }

  Future<void> _runDiagnostic() async {
  final keyword = _keywordController.text.trim().isEmpty
      ? '斗罗'
      : _keywordController.text.trim();

  setState(() {
    _running = true;
    _runtimeError = '';
  });

  BookSourceDiagnosticReport? nextReport;
  String nextError = '';

  try {
    nextReport = await BookSourceDiagnosticRunner.run(
      widget.source,
      keyword: keyword,
    );
  } catch (e) {
    nextError = '诊断执行失败：$e';
  }

  if (!mounted) return;

  setState(() {
    _report = nextReport;
    _runtimeError = nextError;
    _running = false;
  });
}

  Future<void> _copyReport() async {
    final report = _report;
    if (report == null) return;

    await Clipboard.setData(
      ClipboardData(text: report.toPlainText()),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('诊断报告已复制到剪贴板')),
    );
  }

  Color _stateColor(BookSourceDiagnosticStepState state) {
    switch (state) {
      case BookSourceDiagnosticStepState.success:
        return Colors.green;
      case BookSourceDiagnosticStepState.warning:
        return Colors.orange;
      case BookSourceDiagnosticStepState.failure:
        return Colors.redAccent;
      case BookSourceDiagnosticStepState.skipped:
        return Colors.grey;
    }
  }

  IconData _stateIcon(BookSourceDiagnosticStepState state) {
    switch (state) {
      case BookSourceDiagnosticStepState.success:
        return Icons.check_circle_rounded;
      case BookSourceDiagnosticStepState.warning:
        return Icons.warning_amber_rounded;
      case BookSourceDiagnosticStepState.failure:
        return Icons.cancel_rounded;
      case BookSourceDiagnosticStepState.skipped:
        return Icons.skip_next_rounded;
    }
  }

  String _stateText(BookSourceDiagnosticStepState state) {
    switch (state) {
      case BookSourceDiagnosticStepState.success:
        return '成功';
      case BookSourceDiagnosticStepState.warning:
        return '警告';
      case BookSourceDiagnosticStepState.failure:
        return '失败';
      case BookSourceDiagnosticStepState.skipped:
        return '跳过';
    }
  }

  Widget _buildSourceCard() {
    final source = widget.source;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            source.bookSourceName.isNotEmpty ? source.bookSourceName : '未命名书源',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '地址：${source.bookSourceUrl.isNotEmpty ? source.bookSourceUrl : "(空)"}',
            style: const TextStyle(fontSize: 12.5, color: Colors.black54),
          ),
          const SizedBox(height: 6),
          Text(
            '分组：${source.bookSourceGroup.isNotEmpty ? source.bookSourceGroup : "(空)"}',
            style: const TextStyle(fontSize: 12.5, color: Colors.black54),
          ),
          const SizedBox(height: 6),
          Text(
            '搜索：${source.searchUrl.isNotEmpty ? source.searchUrl : "(空)"}',
            style: const TextStyle(fontSize: 12.5, color: Colors.black54),
          ),
          const SizedBox(height: 6),
          Text(
            '发现页：${source.exploreUrl.isNotEmpty ? source.exploreUrl : "(空)"}',
            style: const TextStyle(fontSize: 12.5, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '测试参数',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _keywordController,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _runDiagnostic(),
            decoration: InputDecoration(
              labelText: '测试关键词',
              hintText: '例如：斗罗 / 凡人 / 遮天',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: const Color(0xFFF7F8FA),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _running ? null : _runDiagnostic,
                icon: _running
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.play_arrow_rounded),
                label: Text(_running ? '诊断中...' : '开始诊断'),
              ),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: _report == null || _running ? null : _copyReport,
                icon: const Icon(Icons.copy_rounded),
                label: const Text('复制报告'),
              ),
            ],
          ),
          if (_runtimeError.isNotEmpty) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                _runtimeError,
                style: const TextStyle(
                  color: Colors.redAccent,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSummaryCard(BookSourceDiagnosticReport report) {
    final overallColor = report.hasFailure
        ? Colors.redAccent
        : (report.warningCount > 0 || report.skippedCount > 0)
            ? Colors.orange
            : Colors.green;

    Widget statChip(String text, Color color) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: color,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '总体结果',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: overallColor,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            report.overallSummary,
            style: const TextStyle(
              fontSize: 13.5,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              statChip('成功 ${report.successCount}', Colors.green),
              statChip('警告 ${report.warningCount}', Colors.orange),
              statChip('失败 ${report.failureCount}', Colors.redAccent),
              statChip('跳过 ${report.skippedCount}', Colors.grey),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '关键词：${report.keyword}',
            style: const TextStyle(fontSize: 12.5, color: Colors.black54),
          ),
          const SizedBox(height: 4),
          Text(
            '时间：${report.startedAt.toLocal()}',
            style: const TextStyle(fontSize: 12.5, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  Widget _buildStepCard(BookSourceDiagnosticStep step, int index) {
    final color = _stateColor(step.state);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
          splashColor: Colors.transparent,
        ),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
          leading: Icon(_stateIcon(step.state), color: color),
          title: Text(
            '${index + 1}. ${step.title}',
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 14.5,
            ),
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              step.summary,
              style: const TextStyle(
                fontSize: 12.5,
                color: Colors.black54,
              ),
            ),
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  _stateText(step.state),
                  style: TextStyle(
                    color: color,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${step.durationMs} ms',
                style: const TextStyle(
                  fontSize: 11,
                  color: Colors.black45,
                ),
              ),
            ],
          ),
          children: [
            if (step.detail.trim().isEmpty)
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '暂无更多详情',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.black45,
                  ),
                ),
              )
            else
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F8FA),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: SelectableText(
                  step.detail,
                  style: const TextStyle(
                    fontSize: 13,
                    height: 1.55,
                    color: Colors.black87,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildReportSection() {
    if (_running && _report == null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 40),
        alignment: Alignment.center,
        child: const Column(
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 14),
            Text(
              '正在诊断书源，请稍候...',
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      );
    }

    final report = _report;
    if (report == null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 40),
        alignment: Alignment.center,
        child: const Text(
          '点击“开始诊断”后查看结果',
          style: TextStyle(color: Colors.black54),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSummaryCard(report),
        const SizedBox(height: 12),
        const Text(
          '诊断步骤',
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 10),
        ...report.steps.asMap().entries.map(
              (entry) => _buildStepCard(entry.value, entry.key),
            ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final sourceName = widget.source.bookSourceName.isNotEmpty
        ? widget.source.bookSourceName
        : '书源诊断';

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          sourceName,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            tooltip: '重新诊断',
            onPressed: _running ? null : _runDiagnostic,
            icon: const Icon(Icons.refresh_rounded),
          ),
          IconButton(
            tooltip: '复制报告',
            onPressed: _report == null || _running ? null : _copyReport,
            icon: const Icon(Icons.copy_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _buildSourceCard(),
          const SizedBox(height: 12),
          _buildInputCard(),
          const SizedBox(height: 12),
          _buildReportSection(),
        ],
      ),
    );
  }
}