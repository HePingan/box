import '../../core/models.dart';
import '../../core/rule_novel_source.dart';
import 'book_source_model.dart';

enum BookSourceDiagnosticStepState {
  success,
  warning,
  failure,
  skipped,
}

class BookSourceDiagnosticStep {
  final String title;
  final BookSourceDiagnosticStepState state;
  final int durationMs;
  final String summary;
  final String detail;

  const BookSourceDiagnosticStep({
    required this.title,
    required this.state,
    required this.durationMs,
    required this.summary,
    this.detail = '',
  });
}

class BookSourceDiagnosticReport {
  final String sourceName;
  final String sourceUrl;
  final String keyword;
  final DateTime startedAt;
  final List<BookSourceDiagnosticStep> steps;

  const BookSourceDiagnosticReport({
    required this.sourceName,
    required this.sourceUrl,
    required this.keyword,
    required this.startedAt,
    required this.steps,
  });

  int get successCount =>
      steps.where((e) => e.state == BookSourceDiagnosticStepState.success).length;

  int get warningCount =>
      steps.where((e) => e.state == BookSourceDiagnosticStepState.warning).length;

  int get failureCount =>
      steps.where((e) => e.state == BookSourceDiagnosticStepState.failure).length;

  int get skippedCount =>
      steps.where((e) => e.state == BookSourceDiagnosticStepState.skipped).length;

  bool get hasFailure => failureCount > 0;

  bool get allPassed =>
      !hasFailure && warningCount == 0 && skippedCount == 0;

  String get overallSummary {
    if (allPassed) {
      return '诊断通过：所有关键步骤均成功。';
    }
    if (hasFailure) {
      return '诊断未通过：存在失败步骤，请优先查看失败项。';
    }
    if (warningCount > 0 || skippedCount > 0) {
      return '诊断部分通过：存在警告或跳过项。';
    }
    return '诊断完成。';
  }

  String toPlainText() {
    final buffer = StringBuffer()
      ..writeln('书源诊断报告')
      ..writeln('书源名称：$sourceName')
      ..writeln('书源地址：$sourceUrl')
      ..writeln('测试关键词：$keyword')
      ..writeln('诊断时间：${startedAt.toIso8601String()}')
      ..writeln('总体结果：$overallSummary')
      ..writeln(
        '统计：成功 $successCount，警告 $warningCount，失败 $failureCount，跳过 $skippedCount',
      )
      ..writeln('');

    for (final step in steps) {
      buffer
        ..writeln(
          '[${_labelOf(step.state)}] ${step.title}（${step.durationMs} ms）',
        )
        ..writeln('摘要：${step.summary}');
      if (step.detail.trim().isNotEmpty) {
        buffer.writeln('详情：${step.detail}');
      }
      buffer.writeln('');
    }

    return buffer.toString();
  }

  static String _labelOf(BookSourceDiagnosticStepState state) {
    switch (state) {
      case BookSourceDiagnosticStepState.success:
        return '成功';
      case BookSourceDiagnosticStepState.warning:
        return '警告';
      case BookSourceDiagnosticStepState.failure:
        return '失败';
      case BookSourceDiagnosticStepState.skipped:
        return '跳过';
    }
  }
}

class BookSourceDiagnosticRunner {
  const BookSourceDiagnosticRunner._();

  static Future<BookSourceDiagnosticReport> run(
    BookSourceModel source, {
    String keyword = '斗罗',
  }) async {
    final startedAt = DateTime.now();
    final safeKeyword = keyword.trim().isEmpty ? '斗罗' : keyword.trim();
    final steps = <BookSourceDiagnosticStep>[];

    steps.add(_runBasicCheck(source));

    late final RuleNovelSource sourceImpl;
    try {
      sourceImpl = RuleNovelSource.fromBookSourceJson(source.toJson());
      steps.add(
        const BookSourceDiagnosticStep(
          title: '书源实例化',
          state: BookSourceDiagnosticStepState.success,
          durationMs: 0,
          summary: '规则书源对象创建成功。',
        ),
      );
    } catch (e) {
      steps.add(
        BookSourceDiagnosticStep(
          title: '书源实例化',
          state: BookSourceDiagnosticStepState.failure,
          durationMs: 0,
          summary: '规则书源对象创建失败。',
          detail: '$e',
        ),
      );

      steps.addAll(_buildSkippedSteps(
        const ['搜索测试', '详情测试', '目录测试', '正文测试'],
        reason: '由于书源实例化失败，后续步骤无法继续。',
      ));

      return BookSourceDiagnosticReport(
        sourceName: source.bookSourceName,
        sourceUrl: source.bookSourceUrl,
        keyword: safeKeyword,
        startedAt: startedAt,
        steps: steps,
      );
    }

    List<NovelBook> books = <NovelBook>[];

    // 1. 搜索测试
    {
      final sw = Stopwatch()..start();
      try {
        books = await sourceImpl.searchBooks(safeKeyword, page: 1);
        sw.stop();

        if (books.isEmpty) {
          steps.add(
            BookSourceDiagnosticStep(
              title: '搜索测试',
              state: BookSourceDiagnosticStepState.warning,
              durationMs: sw.elapsedMilliseconds,
              summary: '搜索请求成功，但返回结果为 0 条。',
              detail: [
                '关键词：$safeKeyword',
                '可能原因：',
                '- 该关键词在源站没有结果',
                '- ruleSearch.bookList 规则不匹配',
                '- ruleSearch 字段映射不正确',
              ].join('\n'),
            ),
          );

          steps.addAll(_buildSkippedSteps(
            const ['详情测试', '目录测试', '正文测试'],
            reason: '由于没有搜索结果，无法继续后续诊断。',
          ));

          return BookSourceDiagnosticReport(
            sourceName: source.bookSourceName,
            sourceUrl: source.bookSourceUrl,
            keyword: safeKeyword,
            startedAt: startedAt,
            steps: steps,
          );
        }

        steps.add(
          BookSourceDiagnosticStep(
            title: '搜索测试',
            state: BookSourceDiagnosticStepState.success,
            durationMs: sw.elapsedMilliseconds,
            summary: '搜索成功，返回 ${books.length} 条结果。',
            detail: _buildBookListPreview(books),
          ),
        );
      } catch (e) {
        sw.stop();

        steps.add(
          BookSourceDiagnosticStep(
            title: '搜索测试',
            state: BookSourceDiagnosticStepState.failure,
            durationMs: sw.elapsedMilliseconds,
            summary: '搜索请求失败。',
            detail: '$e',
          ),
        );

        steps.addAll(_buildSkippedSteps(
          const ['详情测试', '目录测试', '正文测试'],
          reason: '由于搜索失败，无法继续后续诊断。',
        ));

        return BookSourceDiagnosticReport(
          sourceName: source.bookSourceName,
          sourceUrl: source.bookSourceUrl,
          keyword: safeKeyword,
          startedAt: startedAt,
          steps: steps,
        );
      }
    }

    final sampleBook = books.first;

    // 2. 详情测试
    late final NovelDetail detail;
    {
      final sw = Stopwatch()..start();
      try {
        detail = await sourceImpl.fetchDetail(
          bookId: sampleBook.id,
          detailUrl: sampleBook.detailUrl.isNotEmpty ? sampleBook.detailUrl : null,
        );
        sw.stop();

        final book = detail.book;
        final hasUsefulMeta = book.title.trim().isNotEmpty ||
            book.author.trim().isNotEmpty ||
            book.intro.trim().isNotEmpty;

        steps.add(
          BookSourceDiagnosticStep(
            title: '详情测试',
            state: hasUsefulMeta
                ? BookSourceDiagnosticStepState.success
                : BookSourceDiagnosticStepState.warning,
            durationMs: sw.elapsedMilliseconds,
            summary: hasUsefulMeta ? '详情获取成功。' : '详情接口成功，但关键信息较少。',
            detail: [
              'bookId：${sampleBook.id}',
              '详情页：${sampleBook.detailUrl.ifBlank("(空)")}',
              '标题：${book.title.ifBlank("(空)")}',
              '作者：${book.author.ifBlank("(空)")}',
              '分类：${book.category.ifBlank("(空)")}',
              '状态：${book.status.ifBlank("(空)")}',
              '字数：${book.wordCount.ifBlank("(空)")}',
              '简介长度：${book.intro.length}',
            ].join('\n'),
          ),
        );
      } catch (e) {
        sw.stop();

        steps.add(
          BookSourceDiagnosticStep(
            title: '详情测试',
            state: BookSourceDiagnosticStepState.failure,
            durationMs: sw.elapsedMilliseconds,
            summary: '详情获取失败。',
            detail: '$e',
          ),
        );

        steps.addAll(_buildSkippedSteps(
          const ['目录测试', '正文测试'],
          reason: '由于详情失败，无法继续目录与正文诊断。',
        ));

        return BookSourceDiagnosticReport(
          sourceName: source.bookSourceName,
          sourceUrl: source.bookSourceUrl,
          keyword: safeKeyword,
          startedAt: startedAt,
          steps: steps,
        );
      }
    }

    // 3. 目录测试
    {
      final chapters = detail.chapters;
      final sw = Stopwatch()..start();
      sw.stop();

      if (chapters.isEmpty) {
        steps.add(
          BookSourceDiagnosticStep(
            title: '目录测试',
            state: BookSourceDiagnosticStepState.warning,
            durationMs: sw.elapsedMilliseconds,
            summary: '详情获取成功，但目录为空。',
            detail: '可能原因：ruleToc 规则未匹配到章节列表，或源站目录接口返回为空。',
          ),
        );

        steps.addAll(_buildSkippedSteps(
          const ['正文测试'],
          reason: '由于目录为空，无法继续正文诊断。',
        ));

        return BookSourceDiagnosticReport(
          sourceName: source.bookSourceName,
          sourceUrl: source.bookSourceUrl,
          keyword: safeKeyword,
          startedAt: startedAt,
          steps: steps,
        );
      }

      steps.add(
        BookSourceDiagnosticStep(
          title: '目录测试',
          state: BookSourceDiagnosticStepState.success,
          durationMs: sw.elapsedMilliseconds,
          summary: '目录获取成功，共 ${chapters.length} 章。',
          detail: _buildChapterPreview(chapters),
        ),
      );
    }

    // 4. 正文测试
    {
      final sw = Stopwatch()..start();
      try {
        final chapter = await sourceImpl.fetchChapter(
          detail: detail,
          chapterIndex: 0,
        );
        sw.stop();

        final text = chapter.content.trim();
        final state = text.length >= 20
            ? BookSourceDiagnosticStepState.success
            : BookSourceDiagnosticStepState.warning;

        steps.add(
          BookSourceDiagnosticStep(
            title: '正文测试',
            state: state,
            durationMs: sw.elapsedMilliseconds,
            summary: text.isNotEmpty ? '正文获取成功。' : '正文接口返回为空。',
            detail: [
              '章节标题：${chapter.title.ifBlank("(空)")}',
              '正文长度：${text.length}',
              '正文预览：',
              _previewContent(text),
            ].join('\n'),
          ),
        );
      } catch (e) {
        sw.stop();

        steps.add(
          BookSourceDiagnosticStep(
            title: '正文测试',
            state: BookSourceDiagnosticStepState.failure,
            durationMs: sw.elapsedMilliseconds,
            summary: '正文获取失败。',
            detail: '$e',
          ),
        );
      }
    }

    return BookSourceDiagnosticReport(
      sourceName: source.bookSourceName,
      sourceUrl: source.bookSourceUrl,
      keyword: safeKeyword,
      startedAt: startedAt,
      steps: steps,
    );
  }

  static BookSourceDiagnosticStep _runBasicCheck(BookSourceModel source) {
    final problems = <String>[];

    if (source.bookSourceName.trim().isEmpty) {
      problems.add('bookSourceName 为空');
    }
    if (source.bookSourceUrl.trim().isEmpty) {
      problems.add('bookSourceUrl 为空');
    }
    if (source.searchUrl.trim().isEmpty) {
      problems.add('searchUrl 为空');
    }

    return BookSourceDiagnosticStep(
      title: '基础规则检查',
      state: problems.isEmpty
          ? BookSourceDiagnosticStepState.success
          : BookSourceDiagnosticStepState.warning,
      durationMs: 0,
      summary: problems.isEmpty ? '基础字段检查通过。' : '存在基础字段缺失。',
      detail: problems.isEmpty ? 'bookSourceName / bookSourceUrl / searchUrl 看起来正常。' : problems.join('\n'),
    );
  }

  static List<BookSourceDiagnosticStep> _buildSkippedSteps(
    List<String> titles, {
    required String reason,
  }) {
    return titles
        .map(
          (title) => BookSourceDiagnosticStep(
            title: title,
            state: BookSourceDiagnosticStepState.skipped,
            durationMs: 0,
            summary: '已跳过。',
            detail: reason,
          ),
        )
        .toList();
  }

  static String _buildBookListPreview(List<NovelBook> books) {
    final preview = books.take(5).toList();
    return preview
        .asMap()
        .entries
        .map((e) {
          final i = e.key + 1;
          final b = e.value;
          final meta = <String>[
            if (b.author.trim().isNotEmpty) b.author,
            if (b.category.trim().isNotEmpty) b.category,
            if (b.status.trim().isNotEmpty) b.status,
          ].join(' · ');

          return '$i. ${b.title.ifBlank("(无书名)")}  ${meta.ifBlank("")}'.trimRight();
        })
        .join('\n');
  }

  static String _buildChapterPreview(List<NovelChapter> chapters) {
    final preview = chapters.take(5).toList();
    return preview
        .asMap()
        .entries
        .map((e) => '${e.key + 1}. ${e.value.title.ifBlank("(无章节名)")}')
        .join('\n');
  }

  static String _previewContent(String text) {
    if (text.trim().isEmpty) return '(空)';
    final normalized = text.replaceAll('\r\n', '\n').trim();
    if (normalized.length <= 200) return normalized;
    return '${normalized.substring(0, 200)}...';
  }
}

extension _BookSourceDiagnosticStringExt on String {
  String ifBlank(String fallback) {
    return trim().isEmpty ? fallback : this;
  }
}