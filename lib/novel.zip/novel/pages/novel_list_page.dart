import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/novel_detail_controller.dart';
import '../controllers/novel_list_controller.dart';
import '../core/models.dart';
import 'novel_detail_page.dart';
import 'source_manager/book_source_manager_page.dart';

/// 统一入口：任何地方要打开小说列表页，都建议使用这个组件
/// 这样可以确保 NovelListPage 上方一定有 NovelListController Provider
class NovelListPageWithProvider extends StatelessWidget {
  const NovelListPageWithProvider({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => NovelListController(),
      child: const NovelListPage(),
    );
  }
}

class NovelListPage extends StatefulWidget {
  const NovelListPage({super.key});

  @override
  State<NovelListPage> createState() => _NovelListPageState();
}

class _NovelListPageState extends State<NovelListPage> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;

    final pos = _scrollController.position;
    if (pos.pixels > pos.maxScrollExtent - 260) {
      context.read<NovelListController>().loadMore();
    }
  }

  void _doSearch() {
    final keyword = _searchController.text.trim();
    if (keyword.isEmpty) return;

    context.read<NovelListController>().search(keyword);
    FocusScope.of(context).unfocus();
  }

  void _cancelSearch() {
    _searchController.clear();
    context.read<NovelListController>().cancelSearch();
  }

  Widget _buildBookCard(BuildContext context, NovelBook book) {
    final meta = <String>[
      if (book.author.isNotEmpty) book.author,
      if (book.category.isNotEmpty) book.category,
      if (book.status.isNotEmpty) book.status,
      if (book.wordCount.isNotEmpty) book.wordCount,
    ].join(' · ');

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChangeNotifierProvider(
              create: (_) => NovelDetailController(entryBook: book),
              child: NovelDetailPage(entryBook: book),
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: book.coverUrl.trim().isNotEmpty
                  ? Image.network(
                      book.coverUrl,
                      width: 64,
                      height: 86,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _buildCoverFallback(),
                    )
                  : _buildCoverFallback(),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: SizedBox(
                height: 86,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      book.title.isNotEmpty ? book.title : '未知书名',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      meta.isNotEmpty ? meta : '暂无信息',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12.5,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      book.intro.isNotEmpty ? book.intro : '还没有简介哦。',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12.5,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCoverFallback() {
    return Container(
      width: 64,
      height: 86,
      color: Colors.grey[200],
      alignment: Alignment.center,
      child: const Icon(Icons.menu_book, color: Colors.black38),
    );
  }

  Widget _buildListBody(BuildContext context) {
    final controller = context.watch<NovelListController>();

    if (!controller.isConfigured) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: const [
          SizedBox(height: 180),
          Center(
            child: Text(
              '未配置规则书源',
              style: TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      );
    }

    if (controller.loading && controller.books.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: const [
          SizedBox(height: 180),
          Center(child: CircularProgressIndicator()),
        ],
      );
    }

    if (controller.books.isEmpty) {
      final tip = controller.searchMode
          ? (controller.error.isNotEmpty ? controller.error : '没有搜索到相关书籍')
          : (controller.supportsExplore
              ? (controller.error.isNotEmpty ? controller.error : '暂无相关数据')
              : '当前书源不支持发现页，请直接搜索');

      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 180),
          Center(
            child: Text(
              tip,
              style: TextStyle(
                color: controller.error.isNotEmpty
                    ? Colors.redAccent
                    : Colors.black54,
              ),
            ),
          ),
        ],
      );
    }

    return ListView.builder(
      controller: _scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      itemCount: controller.books.length + 1,
      itemBuilder: (context, index) {
        if (index < controller.books.length) {
          return _buildBookCard(context, controller.books[index]);
        }

        if (controller.loadingMore) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          );
        }

        if (!controller.hasMore) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(
              child: Text(
                '到底了',
                style: TextStyle(color: Colors.black45),
              ),
            ),
          );
        }

        return const SizedBox(height: 8);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<NovelListController>();

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          '小说',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            tooltip: '书源管理',
            icon: const Icon(Icons.tune),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const BookSourceManagerPage(),
                ),
              );
            },
          ),
          IconButton(
            tooltip: '刷新',
            icon: const Icon(Icons.refresh),
            onPressed: controller.isConfigured
                ? () => controller.reload(forceRefresh: true)
                : null,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _doSearch(),
                    decoration: InputDecoration(
                      hintText: '输入书名或作者名进行搜索',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: controller.searchMode
                          ? IconButton(
                              icon: const Icon(Icons.close),
                              onPressed: _cancelSearch,
                            )
                          : null,
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(vertical: 0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[50],
                    foregroundColor: Colors.blue[700],
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: _doSearch,
                  child: const Text('搜索'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                controller.searchMode
                    ? '搜索结果'
                    : controller.supportsExplore
                        ? '当前显示：书源发现页'
                        : '当前书源不支持发现页，请直接搜索',
                style: const TextStyle(
                  fontSize: 12.5,
                  color: Colors.black54,
                ),
              ),
            ),
          ),
          if (controller.error.isNotEmpty && controller.books.isNotEmpty)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                controller.error,
                style: const TextStyle(
                  color: Colors.redAccent,
                  fontSize: 12.5,
                ),
              ),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: controller.isConfigured
                  ? () => controller.reload(forceRefresh: true)
                  : () async {},
              child: _buildListBody(context),
            ),
          ),
        ],
      ),
    );
  }
}