import 'package:flutter/foundation.dart';

import '../core/models.dart';
import '../core/rule_novel_source.dart';
import '../novel_module.dart';

class NovelListController extends ChangeNotifier {
  bool _searchMode = false;
  String _searchKeyword = '';

  int _page = 1;
  bool _loading = false;
  bool _loadingMore = false;
  bool _hasMore = true;
  String _error = '';

  final List<NovelBook> _books = [];

  NovelListController() {
    _init();
  }

  bool get isConfigured => NovelModule.isConfigured;
  bool get searchMode => _searchMode;
  String get searchKeyword => _searchKeyword;
  bool get loading => _loading;
  bool get loadingMore => _loadingMore;
  bool get hasMore => _hasMore;
  String get error => _error;
  List<NovelBook> get books => List.unmodifiable(_books);

  bool get supportsExplore {
    if (!NovelModule.isConfigured) return false;
    final source = NovelModule.repository.source;
    return source is RuleNovelSource && source.exploreUrl.trim().isNotEmpty;
  }

  void _init() {
    if (!NovelModule.isConfigured) {
      _loading = false;
      _hasMore = false;
      _error = '未配置规则书源';
      notifyListeners();
      return;
    }

    if (supportsExplore) {
      _reload(forceRefresh: false);
    } else {
      _loading = false;
      _hasMore = false;
      _error = '';
      notifyListeners();
    }
  }

  String _bookKey(NovelBook b) {
    if (b.detailUrl.isNotEmpty) return b.detailUrl;
    if (b.id.isNotEmpty) return b.id;
    return '${b.title}_${b.author}';
  }

  List<NovelBook> _mergeBooks(List<NovelBook> oldList, List<NovelBook> nextList) {
    final seen = <String>{};
    final result = <NovelBook>[];

    for (final b in [...oldList, ...nextList]) {
      final key = _bookKey(b);
      if (key.isNotEmpty && seen.add(key)) {
        result.add(b);
      }
    }
    return result;
  }

  String _buildExplorePath(int page) {
    if (!NovelModule.isConfigured) return '';

    final source = NovelModule.repository.source;
    if (source is! RuleNovelSource) return '';

    final template = source.exploreUrl.trim();
    if (template.isEmpty) return '';

    return template
        .replaceAll('{{page}}', '$page')
        .replaceAll('{page}', '$page');
  }

  Future<List<NovelBook>> _fetchPage(
    int page, {
    required bool forceRefresh,
  }) async {
    if (!NovelModule.isConfigured) {
      return const <NovelBook>[];
    }

    if (_searchMode) {
      final keyword = _searchKeyword.trim();
      if (keyword.isEmpty) return const <NovelBook>[];

      return await NovelModule.repository.searchBooks(
        keyword,
        page: page,
        forceRefresh: forceRefresh,
      );
    }

    final path = _buildExplorePath(page);
    if (path.isEmpty) return const <NovelBook>[];

    return await NovelModule.repository.fetchByPath(
      path,
      forceRefresh: forceRefresh,
    );
  }

  Future<void> _reload({required bool forceRefresh}) async {
    _page = 1;
    _loading = true;
    _loadingMore = false;
    _hasMore = true;
    _error = '';
    notifyListeners();

    try {
      final books = await _fetchPage(1, forceRefresh: forceRefresh);
      _books
        ..clear()
        ..addAll(books);

      _hasMore = books.isNotEmpty;
      _error = '';
    } catch (e) {
      _books.clear();
      _hasMore = false;
      _error = '加载失败：$e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> reload({bool forceRefresh = true}) async {
    await _reload(forceRefresh: forceRefresh);
  }

  Future<void> loadMore() async {
    if (_loading || _loadingMore || !_hasMore || !NovelModule.isConfigured) {
      return;
    }

    _loadingMore = true;
    _error = '';
    notifyListeners();

    final nextPage = _page + 1;

    try {
      final books = await _fetchPage(nextPage, forceRefresh: false);
      final before = _books.length;
      final merged = _mergeBooks(_books, books);
      final added = merged.length - before;

      _books
        ..clear()
        ..addAll(merged);

      _page = nextPage;
      _hasMore = books.isNotEmpty && added > 0;
      _error = '';
    } catch (e) {
      _hasMore = false;
      _error = '没有更多数据了';
    } finally {
      _loadingMore = false;
      notifyListeners();
    }
  }

  void search(String keyword) {
    final k = keyword.trim();
    if (k.isEmpty) return;

    if (!NovelModule.isConfigured) {
      _error = '未配置规则书源';
      notifyListeners();
      return;
    }

    _searchMode = true;
    _searchKeyword = k;
    _reload(forceRefresh: true);
  }

  void cancelSearch() {
    if (!_searchMode) return;

    _searchMode = false;
    _searchKeyword = '';
    _page = 1;

    if (supportsExplore) {
      _reload(forceRefresh: false);
    } else {
      _books.clear();
      _hasMore = false;
      _error = '';
      notifyListeners();
    }
  }
}