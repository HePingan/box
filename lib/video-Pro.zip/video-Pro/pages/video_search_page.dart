import 'package:flutter/material.dart';

import '../models/video_source.dart';
import '../models/vod_item.dart';
import '../services/video_api_service.dart';
import 'search/search_empty_state.dart';
import 'search/search_result_card.dart';
import 'search/search_utils.dart'; // 确保你里面有 loadSearchVideoCover
import 'video_detail_page.dart';

class VideoSearchPage extends StatefulWidget {
  final VideoSource currentSource;

  const VideoSearchPage({
    super.key,
    required this.currentSource,
  });

  @override
  State<VideoSearchPage> createState() => _VideoSearchPageState();
}

class _VideoSearchPageState extends State<VideoSearchPage> {
  final TextEditingController _searchController = TextEditingController();

  List<VodItem> _results = [];
  bool _isLoading = false;
  bool _hasSearched = false;
  String? _errorMessage;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _performSearch() async {
    final keyword = _searchController.text.trim();
    if (keyword.isEmpty) return;

    FocusScope.of(context).unfocus();

    setState(() {
      _isLoading = true;
      _hasSearched = true;
      _errorMessage = null;
      _results = [];
    });

    try {
      final res = await VideoApiService.searchVideo(
        widget.currentSource.url,
        keyword,
      );

      if (!mounted) return;

      setState(() {
        _results = res;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _results = [];
        _isLoading = false;
        _errorMessage = '搜索失败：$e';
      });
    }
  }

  void _openDetail(VodItem video) {
    if (video.vodId <= 0) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VideoDetailPage(
          source: widget.currentSource,
          vodId: video.vodId,
        ),
      ),
    );
  }

  String _titleFor(VodItem video) {
    final title = video.vodName.trim();
    return title.isNotEmpty ? title : '未命名';
  }

  String? _subtitleFor(VodItem video) {
    final remarks = video.vodRemarks?.trim();
    if (remarks != null && remarks.isNotEmpty) return remarks;
    final typeName = video.typeName?.trim();
    return (typeName != null && typeName.isNotEmpty) ? typeName : null;
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          autofocus: true,
          decoration: InputDecoration(
            hintText: '在 ${widget.currentSource.name} 中搜索...',
            border: InputBorder.none,
            hintStyle: const TextStyle(fontSize: 15),
          ),
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _performSearch(),
        ),
        actions: [
          IconButton(
            tooltip: '搜索',
            icon: const Icon(Icons.search),
            onPressed: _performSearch,
          ),
          IconButton(
            tooltip: '清空',
            icon: const Icon(Icons.clear_rounded),
            onPressed: () {
              _searchController.clear();
              setState(() {
                _results = [];
                _hasSearched = false;
                _errorMessage = null;
              });
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : !_hasSearched
              ? SearchEmptyState(message: '输入关键词开始搜索', icon: Icons.manage_search_rounded)
              : _errorMessage != null
                  ? _buildErrorView()
                  : _results.isEmpty
                      ? SearchEmptyState(message: '未找到相关视频', actionLabel: '重新搜索', onAction: _performSearch)
                      : GridView.builder(
                          padding: const EdgeInsets.all(12),
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: screenWidth > 600 ? 6 : 3,
                            childAspectRatio: 0.55,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 10,
                          ),
                          itemCount: _results.length,
                          itemBuilder: (context, index) {
                            final video = _results[index];
// 在 video_search_page.dart 中使用 SearchResultCard 的地方，改为：
  return SearchResultCard(
    title: _titleFor(video),
    subtitle: _subtitleFor(video),
    // 👇 就是把这里的属性名从 coverUrlFuture 改为 coverUrl 即可！
    coverUrl: loadSearchVideoCover(video, widget.currentSource), 
    onTap: () => _openDetail(video),
  );
                          },
                        ),
    );
  }

  Widget _buildErrorView() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        const SizedBox(height: 120),
        Icon(Icons.error_outline_rounded, size: 72, color: Colors.grey.shade400),
        const SizedBox(height: 12),
        Center(child: Text(_errorMessage ?? '搜索失败', style: TextStyle(color: Colors.grey.shade700, fontSize: 15))),
        const SizedBox(height: 16),
        Center(child: ElevatedButton.icon(onPressed: _performSearch, icon: const Icon(Icons.refresh_rounded), label: const Text('重试'))),
      ],
    );
  }
}